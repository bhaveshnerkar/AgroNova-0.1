# ─── CROP DATABASE ────────────────────────────────────────────────────────────
# All crop data with multilingual support

CROP_DB = {
    "wheat": {
        "key": "wheat",
        "emoji": "🌾",
        "names": {"english": "Wheat", "hindi": "गेहूं", "marathi": "गहू"},
        "conditions": {
            "soils": ["loamy", "silty", "clay"],
            "ph_min": 6.0, "ph_max": 7.5,
            "temp_min": 10, "temp_max": 25,
            "rain_min": 400, "rain_max": 1200,
            "water": ["medium", "high", "low"]
        },
        "info": {
            "english": {
                "season": "Rabi (Oct-Nov sowing, Mar-Apr harvest)",
                "duration": "120-150 days",
                "yield": "4-6 T/ha",
                "seeds": [
                    {"name": "HD-2967", "yield": "5-6 T/ha", "type": "Disease resistant"},
                    {"name": "GW-322", "yield": "4-5 T/ha", "type": "Drought tolerant"},
                    {"name": "WH-711", "yield": "5-7 T/ha", "type": "High yield"}
                ],
                "pre_planting": [
                    "Deep plow 25-30cm in October",
                    "Apply 15T/ha farmyard manure 2 weeks before",
                    "Level field for uniform irrigation",
                    "Treat seeds with Thiram @ 2.5g/kg",
                    "Ensure soil moisture before sowing"
                ],
                "post_planting": [
                    "First irrigation at 20-25 days (crown root stage)",
                    "Apply nitrogen in 2 splits (50% basal, 50% at tillering)",
                    "Monitor for rust disease after 60 days",
                    "Harvest when grains are hard and golden (135-150 days)",
                    "Thresh when moisture content below 14%"
                ],
                "fertilizers": [
                    {"name": "Urea", "dose": "130 kg/ha", "time": "Split: sowing + tillering"},
                    {"name": "DAP", "dose": "60 kg/ha", "time": "At sowing (basal)"},
                    {"name": "MOP", "dose": "40 kg/ha", "time": "At sowing"},
                    {"name": "Zinc Sulfate", "dose": "25 kg/ha", "time": "Once in 3 years"}
                ]
            },
            "hindi": {
                "season": "रबी (अक्टूबर-नवंबर बुवाई, मार्च-अप्रैल कटाई)",
                "duration": "120-150 दिन",
                "yield": "4-6 टन/हेक्टेयर",
                "seeds": [
                    {"name": "HD-2967", "yield": "5-6 टन/हे.", "type": "रोग प्रतिरोधी"},
                    {"name": "GW-322", "yield": "4-5 टन/हे.", "type": "सूखा सहिष्णु"},
                    {"name": "WH-711", "yield": "5-7 टन/हे.", "type": "उच्च उपज"}
                ],
                "pre_planting": [
                    "अक्टूबर में 25-30 सेमी गहरी जुताई करें",
                    "बुवाई से 2 सप्ताह पहले 15 टन/हे. गोबर खाद डालें",
                    "समान सिंचाई के लिए खेत को समतल करें",
                    "थीरम @ 2.5 ग्राम/किलो से बीज उपचार करें",
                    "बुवाई से पहले मिट्टी में नमी सुनिश्चित करें"
                ],
                "post_planting": [
                    "पहली सिंचाई 20-25 दिनों पर करें",
                    "नाइट्रोजन दो भागों में दें",
                    "60 दिनों बाद रस्ट रोग की निगरानी करें",
                    "जब दाने सख्त और सुनहरे हों तब कटाई करें",
                    "जब नमी 14% से कम हो तब मड़ाई करें"
                ],
                "fertilizers": [
                    {"name": "यूरिया", "dose": "130 किग्रा/हे.", "time": "बुवाई + कल्ले निकलने पर"},
                    {"name": "DAP", "dose": "60 किग्रा/हे.", "time": "बुवाई के समय"},
                    {"name": "MOP", "dose": "40 किग्रा/हे.", "time": "बुवाई के समय"},
                    {"name": "जिंक सल्फेट", "dose": "25 किग्रा/हे.", "time": "3 वर्ष में एक बार"}
                ]
            },
            "marathi": {
                "season": "रब्बी (ऑक्टोबर-नोव्हेंबर पेरणी, मार्च-एप्रिल कापणी)",
                "duration": "120-150 दिवस",
                "yield": "4-6 टन/हेक्टर",
                "seeds": [
                    {"name": "HD-2967", "yield": "5-6 टन/हे.", "type": "रोगप्रतिकारक"},
                    {"name": "GW-322", "yield": "4-5 टन/हे.", "type": "दुष्काळ सहनशील"},
                    {"name": "WH-711", "yield": "5-7 टन/हे.", "type": "उच्च उत्पादन"}
                ],
                "pre_planting": [
                    "ऑक्टोबरमध्ये 25-30 सेमी खोल नांगरणी करा",
                    "पेरणीपूर्वी 2 आठवडे 15 टन/हे. शेणखत घाला",
                    "समान सिंचनासाठी शेत सपाट करा",
                    "थीरम @ 2.5 ग्रॅम/किलो बीज प्रक्रिया करा",
                    "पेरणीपूर्वी जमिनीत ओलावा असल्याची खात्री करा"
                ],
                "post_planting": [
                    "पहिले पाणी 20-25 दिवसांनी द्या",
                    "नायट्रोजन दोन हप्त्यांत द्या",
                    "60 दिवसांनंतर गंज रोगाची तपासणी करा",
                    "दाणे कठीण व सोनेरी झाल्यावर कापणी करा",
                    "ओलावा 14% पेक्षा कमी असताना मळणी करा"
                ],
                "fertilizers": [
                    {"name": "युरिया", "dose": "130 किग्रॅ/हे.", "time": "पेरणी + फुटवे निघताना"},
                    {"name": "DAP", "dose": "60 किग्रॅ/हे.", "time": "पेरणीच्या वेळी"},
                    {"name": "MOP", "dose": "40 किग्रॅ/हे.", "time": "पेरणीच्या वेळी"},
                    {"name": "झिंक सल्फेट", "dose": "25 किग्रॅ/हे.", "time": "3 वर्षांतून एकदा"}
                ]
            }
        },
        "cost_per_ha": 35000,
        "yield_per_ha": 5.5,
        "tags": ["Rabi", "Cold climate", "Staple"]
    },

    "rice": {
        "key": "rice",
        "emoji": "🌾",
        "names": {"english": "Rice", "hindi": "चावल / धान", "marathi": "भात / तांदूळ"},
        "conditions": {
            "soils": ["clay", "silty", "loamy"],
            "ph_min": 5.5, "ph_max": 7.0,
            "temp_min": 20, "temp_max": 37,
            "rain_min": 1000, "rain_max": 3000,
            "water": ["high"]
        },
        "info": {
            "english": {
                "season": "Kharif (Jun-Jul sowing, Oct-Nov harvest)",
                "duration": "110-150 days",
                "yield": "5-7 T/ha",
                "seeds": [
                    {"name": "IR-64", "yield": "6-7 T/ha", "type": "High yield"},
                    {"name": "Basmati 370", "yield": "3-4 T/ha", "type": "Premium quality"},
                    {"name": "Swarna MTU-7029", "yield": "5-6 T/ha", "type": "Flood tolerant"}
                ],
                "pre_planting": [
                    "Prepare nursery 25-30 days before transplanting",
                    "Puddle field thoroughly (2-3 ploughings with water)",
                    "Apply 10T/ha FYM 2 weeks before transplanting",
                    "Treat seeds with hot water at 55°C for 10 minutes",
                    "Ensure 5cm standing water before transplanting"
                ],
                "post_planting": [
                    "Maintain 5cm standing water for first 4 weeks",
                    "Apply nitrogen in 3 splits (basal, tillering, panicle initiation)",
                    "Drain field 10 days before harvest",
                    "Watch for blast disease during humid weather",
                    "Harvest at 80-85% grain maturity"
                ],
                "fertilizers": [
                    {"name": "Urea", "dose": "120 kg/ha", "time": "3 equal splits"},
                    {"name": "SSP", "dose": "375 kg/ha", "time": "At transplanting"},
                    {"name": "MOP", "dose": "60 kg/ha", "time": "At transplanting"},
                    {"name": "Zinc Sulfate", "dose": "25 kg/ha", "time": "Basal application"}
                ]
            },
            "hindi": {
                "season": "खरीफ (जून-जुलाई बुवाई, अक्टूबर-नवंबर कटाई)",
                "duration": "110-150 दिन",
                "yield": "5-7 टन/हेक्टेयर",
                "seeds": [
                    {"name": "IR-64", "yield": "6-7 टन/हे.", "type": "उच्च उपज"},
                    {"name": "बासमती 370", "yield": "3-4 टन/हे.", "type": "प्रीमियम गुणवत्ता"},
                    {"name": "स्वर्ण MTU-7029", "yield": "5-6 टन/हे.", "type": "बाढ़ सहिष्णु"}
                ],
                "pre_planting": [
                    "रोपाई से 25-30 दिन पहले नर्सरी तैयार करें",
                    "खेत को अच्छी तरह से पडलिंग करें",
                    "रोपाई से 2 सप्ताह पहले 10 टन/हे. गोबर खाद डालें",
                    "बीजों को 55°C गर्म पानी में 10 मिनट उपचारित करें",
                    "रोपाई से पहले 5 सेमी खड़ा पानी सुनिश्चित करें"
                ],
                "post_planting": [
                    "पहले 4 हफ्तों में 5 सेमी खड़ा पानी बनाए रखें",
                    "नाइट्रोजन तीन भागों में दें",
                    "कटाई से 10 दिन पहले पानी निकालें",
                    "नम मौसम में ब्लास्ट रोग पर नजर रखें",
                    "80-85% दाना परिपक्वता पर कटाई करें"
                ],
                "fertilizers": [
                    {"name": "यूरिया", "dose": "120 किग्रा/हे.", "time": "3 समान भागों में"},
                    {"name": "SSP", "dose": "375 किग्रा/हे.", "time": "रोपाई के समय"},
                    {"name": "MOP", "dose": "60 किग्रा/हे.", "time": "रोपाई के समय"},
                    {"name": "जिंक सल्फेट", "dose": "25 किग्रा/हे.", "time": "मूल खुराक"}
                ]
            },
            "marathi": {
                "season": "खरीप (जून-जुलै पेरणी, ऑक्टोबर-नोव्हेंबर कापणी)",
                "duration": "110-150 दिवस",
                "yield": "5-7 टन/हेक्टर",
                "seeds": [
                    {"name": "IR-64", "yield": "6-7 टन/हे.", "type": "उच्च उत्पादन"},
                    {"name": "बासमती 370", "yield": "3-4 टन/हे.", "type": "उच्च दर्जा"},
                    {"name": "स्वर्ण MTU-7029", "yield": "5-6 टन/हे.", "type": "पूरसहन"}
                ],
                "pre_planting": [
                    "लावणीपूर्वी 25-30 दिवस रोपवाटिका तयार करा",
                    "शेत चांगले चिखलायुक्त करा",
                    "लावणीपूर्वी 2 आठवडे 10 टन/हे. शेणखत घाला",
                    "बियाण्यांवर 55°C गरम पाण्याने 10 मिनिटे प्रक्रिया करा",
                    "लावणीपूर्वी 5 सेमी उभे पाणी असल्याची खात्री करा"
                ],
                "post_planting": [
                    "पहिल्या 4 आठवड्यांत 5 सेमी उभे पाणी ठेवा",
                    "नायट्रोजन तीन हप्त्यांत द्या",
                    "कापणीपूर्वी 10 दिवस पाणी काढा",
                    "दमट हवामानात ब्लास्ट रोगावर लक्ष ठेवा",
                    "80-85% दाणे परिपक्व झाल्यावर कापणी करा"
                ],
                "fertilizers": [
                    {"name": "युरिया", "dose": "120 किग्रॅ/हे.", "time": "3 समान हप्त्यांत"},
                    {"name": "SSP", "dose": "375 किग्रॅ/हे.", "time": "लावणीच्या वेळी"},
                    {"name": "MOP", "dose": "60 किग्रॅ/हे.", "time": "लावणीच्या वेळी"},
                    {"name": "झिंक सल्फेट", "dose": "25 किग्रॅ/हे.", "time": "मूळ मात्रा"}
                ]
            }
        },
        "cost_per_ha": 45000,
        "yield_per_ha": 6.0,
        "tags": ["Kharif", "Wet land", "Staple"]
    },

    "maize": {
        "key": "maize",
        "emoji": "🌽",
        "names": {"english": "Maize (Corn)", "hindi": "मक्का", "marathi": "मका"},
        "conditions": {
            "soils": ["loamy", "sandy", "silty"],
            "ph_min": 5.8, "ph_max": 7.0,
            "temp_min": 18, "temp_max": 35,
            "rain_min": 500, "rain_max": 1500,
            "water": ["medium", "high", "low"]
        },
        "info": {
            "english": {
                "season": "Kharif (Jun-Jul) or Rabi (Oct-Nov)",
                "duration": "90-120 days",
                "yield": "7-10 T/ha",
                "seeds": [
                    {"name": "DKC-9144", "yield": "8-10 T/ha", "type": "Hybrid, high yield"},
                    {"name": "HQPM-1", "yield": "5-6 T/ha", "type": "Quality protein maize"},
                    {"name": "Pioneer-3522", "yield": "9-11 T/ha", "type": "Drought tolerant"}
                ],
                "pre_planting": [
                    "Deep tillage 30cm followed by 2 harrowing",
                    "Apply 10T/ha FYM and incorporate well",
                    "Treat seeds with fungicide and insecticide",
                    "Ensure soil temperature above 18°C at planting",
                    "Ridge and furrow method for better drainage"
                ],
                "post_planting": [
                    "First irrigation immediately after sowing",
                    "Earth-up plants at knee-high stage (30 days)",
                    "Top-dress nitrogen at V6 stage (6 leaves)",
                    "Detassel before pollination for hybrid varieties",
                    "Harvest when husks turn brown and dry"
                ],
                "fertilizers": [
                    {"name": "Urea", "dose": "260 kg/ha", "time": "Split: sowing + V6 + tasseling"},
                    {"name": "DAP", "dose": "80 kg/ha", "time": "Basal at sowing"},
                    {"name": "MOP", "dose": "67 kg/ha", "time": "Basal at sowing"},
                    {"name": "Boron", "dose": "1 kg/ha", "time": "Foliar spray at tasseling"}
                ]
            },
            "hindi": {
                "season": "खरीफ (जून-जुलाई) या रबी (अक्टूबर-नवंबर)",
                "duration": "90-120 दिन",
                "yield": "7-10 टन/हेक्टेयर",
                "seeds": [
                    {"name": "DKC-9144", "yield": "8-10 टन/हे.", "type": "हाइब्रिड, उच्च उपज"},
                    {"name": "HQPM-1", "yield": "5-6 टन/हे.", "type": "गुणवत्ता प्रोटीन मक्का"},
                    {"name": "Pioneer-3522", "yield": "9-11 टन/हे.", "type": "सूखा सहिष्णु"}
                ],
                "pre_planting": [
                    "30 सेमी गहरी जुताई करें फिर 2 बार हैरो चलाएं",
                    "10 टन/हे. गोबर खाद मिलाएं",
                    "फफूंदनाशक और कीटनाशक से बीज उपचार करें",
                    "बुवाई पर मिट्टी का तापमान 18°C से ऊपर सुनिश्चित करें",
                    "बेहतर जल निकास के लिए रिज-फर्रो विधि अपनाएं"
                ],
                "post_planting": [
                    "बुवाई के तुरंत बाद पहली सिंचाई करें",
                    "30 दिनों पर (घुटने जितनी ऊंचाई) मिट्टी चढ़ाएं",
                    "V6 अवस्था में नाइट्रोजन की टॉप ड्रेसिंग करें",
                    "हाइब्रिड किस्मों में परागण से पहले डिटैसलिंग करें",
                    "जब भूसी भूरी और सूखी हो जाए तब कटाई करें"
                ],
                "fertilizers": [
                    {"name": "यूरिया", "dose": "260 किग्रा/हे.", "time": "बुवाई + V6 + टैसलिंग"},
                    {"name": "DAP", "dose": "80 किग्रा/हे.", "time": "बुवाई के समय"},
                    {"name": "MOP", "dose": "67 किग्रा/हे.", "time": "बुवाई के समय"},
                    {"name": "बोरोन", "dose": "1 किग्रा/हे.", "time": "टैसलिंग पर पर्णीय छिड़काव"}
                ]
            },
            "marathi": {
                "season": "खरीप (जून-जुलै) किंवा रब्बी (ऑक्टोबर-नोव्हेंबर)",
                "duration": "90-120 दिवस",
                "yield": "7-10 टन/हेक्टर",
                "seeds": [
                    {"name": "DKC-9144", "yield": "8-10 टन/हे.", "type": "हायब्रीड, उच्च उत्पादन"},
                    {"name": "HQPM-1", "yield": "5-6 टन/हे.", "type": "गुणवत्ता प्रथिने मका"},
                    {"name": "Pioneer-3522", "yield": "9-11 टन/हे.", "type": "दुष्काळ सहनशील"}
                ],
                "pre_planting": [
                    "30 सेमी खोल नांगरणी करा नंतर 2 वेळा कुळव चालवा",
                    "10 टन/हे. शेणखत मिसळा",
                    "बुरशीनाशक आणि कीटकनाशकाने बीज प्रक्रिया करा",
                    "पेरणीच्या वेळी जमिनीचे तापमान 18°C वर असल्याची खात्री करा",
                    "चांगल्या निचऱ्यासाठी रिज-फर्रो पद्धत वापरा"
                ],
                "post_planting": [
                    "पेरणीनंतर लगेच पहिले पाणी द्या",
                    "30 दिवसांनी (गुडघ्याएवढी उंची) माती चढवा",
                    "V6 अवस्थेत नायट्रोजन टॉप ड्रेसिंग करा",
                    "हायब्रीड वाणांमध्ये परागीभवनापूर्वी डिटॅसलिंग करा",
                    "टरफले तपकिरी व कोरडी झाल्यावर कापणी करा"
                ],
                "fertilizers": [
                    {"name": "युरिया", "dose": "260 किग्रॅ/हे.", "time": "पेरणी + V6 + टॅसलिंग"},
                    {"name": "DAP", "dose": "80 किग्रॅ/हे.", "time": "पेरणीच्या वेळी"},
                    {"name": "MOP", "dose": "67 किग्रॅ/हे.", "time": "पेरणीच्या वेळी"},
                    {"name": "बोरॉन", "dose": "1 किग्रॅ/हे.", "time": "टॅसलिंगवर पर्णीय फवारणी"}
                ]
            }
        },
        "cost_per_ha": 40000,
        "yield_per_ha": 9.0,
        "tags": ["Kharif/Rabi", "Versatile", "Feed crop"]
    },

    "soybean": {
        "key": "soybean",
        "emoji": "🫘",
        "names": {"english": "Soybean", "hindi": "सोयाबीन", "marathi": "सोयाबीन"},
        "conditions": {
            "soils": ["loamy", "clay", "silty"],
            "ph_min": 6.0, "ph_max": 7.0,
            "temp_min": 20, "temp_max": 32,
            "rain_min": 600, "rain_max": 1500,
            "water": ["medium", "high"]
        },
        "info": {
            "english": {
                "season": "Kharif (Jun-Jul sowing, Oct harvest)",
                "duration": "90-110 days",
                "yield": "2.5-3.5 T/ha",
                "seeds": [
                    {"name": "JS-335", "yield": "2.5-3 T/ha", "type": "Most popular variety"},
                    {"name": "NRC-37", "yield": "2-2.5 T/ha", "type": "Early maturing"},
                    {"name": "MAUS-81", "yield": "2.5-3.5 T/ha", "type": "High protein"}
                ],
                "pre_planting": [
                    "1-2 deep plowings to break hard pan",
                    "Apply 5T/ha FYM 2 weeks before sowing",
                    "Inoculate seeds with Rhizobium culture",
                    "Broad-bed furrow preparation for drainage",
                    "Optimal sowing: last week of June"
                ],
                "post_planting": [
                    "First weeding at 20-25 days (critical period)",
                    "No irrigation needed if rainfall above 600mm well distributed",
                    "Foliar spray of iron if yellowing appears",
                    "Watch for pod borer at flowering stage",
                    "Harvest when 95% pods turn yellow-brown"
                ],
                "fertilizers": [
                    {"name": "DAP", "dose": "80 kg/ha", "time": "Basal only"},
                    {"name": "MOP", "dose": "40 kg/ha", "time": "Basal"},
                    {"name": "Sulfur", "dose": "20 kg/ha", "time": "Basal"},
                    {"name": "Micronutrient Mix", "dose": "10 kg/ha", "time": "At sowing"}
                ]
            },
            "hindi": {
                "season": "खरीफ (जून-जुलाई बुवाई, अक्टूबर कटाई)",
                "duration": "90-110 दिन",
                "yield": "2.5-3.5 टन/हेक्टेयर",
                "seeds": [
                    {"name": "JS-335", "yield": "2.5-3 टन/हे.", "type": "सबसे लोकप्रिय"},
                    {"name": "NRC-37", "yield": "2-2.5 टन/हे.", "type": "जल्दी पकने वाली"},
                    {"name": "MAUS-81", "yield": "2.5-3.5 टन/हे.", "type": "उच्च प्रोटीन"}
                ],
                "pre_planting": [
                    "कठोर परत तोड़ने के लिए 1-2 बार गहरी जुताई करें",
                    "बुवाई से 2 सप्ताह पहले 5 टन/हे. गोबर खाद डालें",
                    "राइजोबियम कल्चर से बीज उपचार करें",
                    "जल निकास के लिए बॉड-बेड-फर्रो तैयार करें",
                    "जून के अंतिम सप्ताह में बुवाई करें"
                ],
                "post_planting": [
                    "20-25 दिनों पर पहली निराई करें",
                    "600मिमी से अधिक समान बारिश होने पर सिंचाई नहीं चाहिए",
                    "पीलापन दिखने पर लोहे का पर्णीय छिड़काव करें",
                    "फूल आने पर फली छेदक कीट पर नजर रखें",
                    "95% फलियां पीली-भूरी होने पर कटाई करें"
                ],
                "fertilizers": [
                    {"name": "DAP", "dose": "80 किग्रा/हे.", "time": "केवल मूल खुराक"},
                    {"name": "MOP", "dose": "40 किग्रा/हे.", "time": "मूल"},
                    {"name": "सल्फर", "dose": "20 किग्रा/हे.", "time": "मूल"},
                    {"name": "सूक्ष्म पोषक तत्व मिश्रण", "dose": "10 किग्रा/हे.", "time": "बुवाई के समय"}
                ]
            },
            "marathi": {
                "season": "खरीप (जून-जुलै पेरणी, ऑक्टोबर कापणी)",
                "duration": "90-110 दिवस",
                "yield": "2.5-3.5 टन/हेक्टर",
                "seeds": [
                    {"name": "JS-335", "yield": "2.5-3 टन/हे.", "type": "सर्वात लोकप्रिय"},
                    {"name": "NRC-37", "yield": "2-2.5 टन/हे.", "type": "लवकर पिकणारे"},
                    {"name": "MAUS-81", "yield": "2.5-3.5 टन/हे.", "type": "उच्च प्रथिने"}
                ],
                "pre_planting": [
                    "कठीण थर तोडण्यासाठी 1-2 वेळा खोल नांगरणी करा",
                    "पेरणीपूर्वी 2 आठवडे 5 टन/हे. शेणखत घाला",
                    "रायझोबियम कल्चरने बीज प्रक्रिया करा",
                    "निचऱ्यासाठी ब्रॉड-बेड-फर्रो तयार करा",
                    "जूनच्या शेवटच्या आठवड्यात पेरणी करा"
                ],
                "post_planting": [
                    "20-25 दिवसांनी पहिली खुरपणी करा",
                    "600 मिमी पेक्षा जास्त समान पाऊस असल्यास सिंचन नको",
                    "पिवळेपणा दिसल्यास लोहाची पर्णीय फवारणी करा",
                    "फुलोऱ्यात शेंगा पोखरणाऱ्या अळीवर लक्ष ठेवा",
                    "95% शेंगा पिवळ्या-तपकिरी झाल्यावर कापणी करा"
                ],
                "fertilizers": [
                    {"name": "DAP", "dose": "80 किग्रॅ/हे.", "time": "फक्त मूळ मात्रा"},
                    {"name": "MOP", "dose": "40 किग्रॅ/हे.", "time": "मूळ"},
                    {"name": "सल्फर", "dose": "20 किग्रॅ/हे.", "time": "मूळ"},
                    {"name": "सूक्ष्म अन्नद्रव्य मिश्रण", "dose": "10 किग्रॅ/हे.", "time": "पेरणीच्या वेळी"}
                ]
            }
        },
        "cost_per_ha": 30000,
        "yield_per_ha": 2.8,
        "tags": ["Kharif", "Oil crop", "Protein rich"]
    },

    "cotton": {
        "key": "cotton",
        "emoji": "🌿",
        "names": {"english": "Cotton", "hindi": "कपास", "marathi": "कापूस"},
        "conditions": {
            "soils": ["clay", "loamy", "silty"],
            "ph_min": 5.8, "ph_max": 8.0,
            "temp_min": 20, "temp_max": 40,
            "rain_min": 500, "rain_max": 1200,
            "water": ["medium", "low"]
        },
        "info": {
            "english": {
                "season": "Kharif (May-Jun sowing, Nov-Jan harvest)",
                "duration": "180-200 days",
                "yield": "20-30 quintals/ha",
                "seeds": [
                    {"name": "Bt-Cotton RCH-2", "yield": "22-25 q/ha", "type": "Bollworm resistant"},
                    {"name": "MRC-7017 Bt", "yield": "18-22 q/ha", "type": "Drought tolerant"},
                    {"name": "JKCH-1947", "yield": "24-28 q/ha", "type": "Extra long staple"}
                ],
                "pre_planting": [
                    "Deep plowing after pre-monsoon showers",
                    "Apply 10T/ha FYM 3 weeks before sowing",
                    "Ridge and furrow preparation for drainage",
                    "Seed treatment with Imidacloprid",
                    "Optimal sowing: June-July (Kharif)"
                ],
                "post_planting": [
                    "Thinning at 10-15 days (keep 1 plant/hill)",
                    "Apply growth regulator at squaring stage",
                    "Monitor for bollworm and whitefly weekly",
                    "Regulate irrigation — avoid waterlogging",
                    "Harvest open bolls every 7-10 days"
                ],
                "fertilizers": [
                    {"name": "Urea", "dose": "87 kg/ha", "time": "Split: sowing + 30 + 60 days"},
                    {"name": "SSP", "dose": "375 kg/ha", "time": "Basal"},
                    {"name": "MOP", "dose": "67 kg/ha", "time": "Basal"},
                    {"name": "Foliar Boron", "dose": "0.2%", "time": "At flowering"}
                ]
            },
            "hindi": {
                "season": "खरीफ (मई-जून बुवाई, नवंबर-जनवरी कटाई)",
                "duration": "180-200 दिन",
                "yield": "20-30 क्विंटल/हेक्टेयर",
                "seeds": [
                    {"name": "Bt-कपास RCH-2", "yield": "22-25 क्विंटल/हे.", "type": "बोलवर्म प्रतिरोधी"},
                    {"name": "MRC-7017 Bt", "yield": "18-22 क्विंटल/हे.", "type": "सूखा सहिष्णु"},
                    {"name": "JKCH-1947", "yield": "24-28 क्विंटल/हे.", "type": "अतिरिक्त लंबा रेशा"}
                ],
                "pre_planting": [
                    "मानसून पूर्व बारिश के बाद गहरी जुताई करें",
                    "बुवाई से 3 सप्ताह पहले 10 टन/हे. गोबर खाद डालें",
                    "जल निकास के लिए रिज-फर्रो तैयार करें",
                    "इमिडाक्लोप्रिड से बीज उपचार करें",
                    "जून-जुलाई में बुवाई करें"
                ],
                "post_planting": [
                    "10-15 दिनों पर विरलन करें (1 पौधा/हिल)",
                    "स्क्वेयरिंग अवस्था पर वृद्धि नियामक दें",
                    "साप्ताहिक बोलवर्म और सफेद मक्खी की निगरानी करें",
                    "सिंचाई नियंत्रित करें - जलभराव से बचें",
                    "हर 7-10 दिनों में खुले टिंडों की कटाई करें"
                ],
                "fertilizers": [
                    {"name": "यूरिया", "dose": "87 किग्रा/हे.", "time": "बुवाई + 30 + 60 दिन"},
                    {"name": "SSP", "dose": "375 किग्रा/हे.", "time": "मूल खुराक"},
                    {"name": "MOP", "dose": "67 किग्रा/हे.", "time": "मूल"},
                    {"name": "पर्णीय बोरोन", "dose": "0.2%", "time": "फूल आने पर"}
                ]
            },
            "marathi": {
                "season": "खरीप (मे-जून पेरणी, नोव्हेंबर-जानेवारी वेचणी)",
                "duration": "180-200 दिवस",
                "yield": "20-30 क्विंटल/हेक्टर",
                "seeds": [
                    {"name": "Bt-कापूस RCH-2", "yield": "22-25 क्विंटल/हे.", "type": "बोलवर्म प्रतिकारक"},
                    {"name": "MRC-7017 Bt", "yield": "18-22 क्विंटल/हे.", "type": "दुष्काळ सहनशील"},
                    {"name": "JKCH-1947", "yield": "24-28 क्विंटल/हे.", "type": "अतिरिक्त लांब धागा"}
                ],
                "pre_planting": [
                    "मान्सूनपूर्व पावसानंतर खोल नांगरणी करा",
                    "पेरणीपूर्वी 3 आठवडे 10 टन/हे. शेणखत घाला",
                    "निचऱ्यासाठी रिज-फर्रो तयार करा",
                    "इमिडाक्लोप्रिडने बीज प्रक्रिया करा",
                    "जून-जुलैमध्ये पेरणी करा"
                ],
                "post_planting": [
                    "10-15 दिवसांनी विरळणी करा (1 रोप/ओळ)",
                    "स्क्वेअरिंग अवस्थेत वाढ नियामक द्या",
                    "साप्ताहिक बोलवर्म आणि पांढरी माशी तपासा",
                    "पाणी नियंत्रित द्या - साचणे टाळा",
                    "दर 7-10 दिवसांनी उमललेल्या बोंडांची वेचणी करा"
                ],
                "fertilizers": [
                    {"name": "युरिया", "dose": "87 किग्रॅ/हे.", "time": "पेरणी + 30 + 60 दिवस"},
                    {"name": "SSP", "dose": "375 किग्रॅ/हे.", "time": "मूळ मात्रा"},
                    {"name": "MOP", "dose": "67 किग्रॅ/हे.", "time": "मूळ"},
                    {"name": "पर्णीय बोरॉन", "dose": "0.2%", "time": "फुलोऱ्यात"}
                ]
            }
        },
        "cost_per_ha": 55000,
        "yield_per_ha": 2.5,
        "tags": ["Kharif", "Cash crop", "Hot climate"]
    }
}

# ─── SOIL TYPE MAPPING ─────────────────────────────────────────────────────────
# Maps multilingual soil names to standard keys
SOIL_MAP = {
    # English
    "loamy": "loamy", "loam": "loamy",
    "clay": "clay", "clayey": "clay",
    "sandy": "sandy", "sand": "sandy",
    "silty": "silty", "silt": "silty",
    "black": "clay",  # Black cotton soil = clay
    "red": "loamy",
    "alluvial": "loamy",
    # Hindi
    "दोमट": "loamy", "चिकनी": "clay", "बलुई": "sandy",
    "काली": "clay", "लाल": "loamy", "जलोढ़": "loamy",
    "काली मिट्टी": "clay", "लाल मिट्टी": "loamy",
    "रेतीली": "sandy",
    # Marathi
    "चिकण": "clay", "वालुकामय": "sandy", "गाळाची": "silty",
    "काळी": "clay", "लाल माती": "loamy", "जांभ्या": "loamy",
    "काळी माती": "clay", "मध्यम काळी": "clay",
    "हलकी माती": "sandy", "भारी माती": "clay",
}

WATER_MAP = {
    "high": "high", "good": "high", "plenty": "high", "abundant": "high",
    "medium": "medium", "moderate": "medium", "average": "medium", "seasonal": "medium",
    "low": "low", "scarce": "low", "limited": "low",
    "none": "none", "no water": "none", "rain fed": "low", "rainfed": "low",
    # Hindi
    "अधिक": "high", "पर्याप्त": "high",
    "मध्यम": "medium", "सामान्य": "medium",
    "कम": "low", "सीमित": "low",
    "बारिश पर निर्भर": "low",
    # Marathi
    "भरपूर": "high", "पुरेसे": "high",
    "मध्यम": "medium", "साधारण": "medium",
    "कमी": "low", "मर्यादित": "low",
    "पावसावर अवलंबून": "low",
}

# ─── SCORING FUNCTION ──────────────────────────────────────────────────────────

def score_crop(crop: dict, soil_type: str, temperature: float,
               rainfall: float, water_level: str) -> int:
    c = crop["conditions"]
    score = 0

    # Soil match (25 pts)
    if soil_type in c["soils"]:
        score += 25
    elif any(s in ["loamy", "silty"] for s in [soil_type] + c["soils"]):
        score += 10

    # Temperature match (25 pts)
    if c["temp_min"] <= temperature <= c["temp_max"]:
        score += 25
    elif c["temp_min"] - 5 <= temperature <= c["temp_max"] + 5:
        score += 10

    # Rainfall match (25 pts)
    if c["rain_min"] <= rainfall <= c["rain_max"]:
        score += 25
    elif rainfall >= c["rain_min"] * 0.7:
        score += 12

    # Water level match (25 pts)
    if water_level in c["water"]:
        score += 25
    elif water_level == "medium" or "medium" in c["water"]:
        score += 10

    return min(score, 100)


def recommend_crops(soil_type: str, temperature: float, rainfall: float,
                    humidity: float, water_level: str, language: str = "english") -> list:
    lang = language.lower()
    if lang not in ["english", "hindi", "marathi"]:
        lang = "english"

    # Normalize soil and water inputs
    soil_key = SOIL_MAP.get(soil_type.lower(), "loamy")
    water_key = WATER_MAP.get(water_level.lower(), "medium")

    # Score all crops
    scored = []
    for key, crop in CROP_DB.items():
        s = score_crop(crop, soil_key, temperature, rainfall, water_key)
        name = crop["names"].get(lang, crop["names"]["english"])
        scored.append({
            "key": key,
            "name": name,
            "emoji": crop["emoji"],
            "score": s,
            "tags": crop["tags"],
            "season": crop["info"][lang]["season"] if lang in crop["info"] else crop["info"]["english"]["season"],
            "yield": crop["info"]["english"]["yield"],
            "cost_per_ha": crop["cost_per_ha"],
        })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:3]


def get_crop_guidance(crop_key: str, language: str = "english",
                      area_hectares: float = 1.0) -> dict:
    crop = CROP_DB.get(crop_key)
    if not crop:
        return None

    lang = language.lower()
    if lang not in ["english", "hindi", "marathi"]:
        lang = "english"

    info = crop["info"].get(lang, crop["info"]["english"])
    name = crop["names"].get(lang, crop["names"]["english"])

    # Calculator
    total_cost = round(crop["cost_per_ha"] * area_hectares)
    yield_tons = crop["yield_per_ha"] * area_hectares
    yield_quintals = yield_tons * 10

    market_prices = {
        "wheat": 2200, "rice": 2100, "maize": 1800,
        "cotton": 6500, "soybean": 4200
    }
    price_per_q = market_prices.get(crop_key, 2000)
    revenue = round(yield_quintals * price_per_q)
    profit = revenue - total_cost
    roi = round((profit / total_cost) * 100) if total_cost > 0 else 0

    return {
        "key": crop_key,
        "name": name,
        "emoji": crop["emoji"],
        "language": lang,
        "info": info,
        "calculator": {
            "area_hectares": area_hectares,
            "total_cost": total_cost,
            "yield_tons": round(yield_tons, 2),
            "yield_quintals": round(yield_quintals, 1),
            "price_per_quintal": price_per_q,
            "revenue": revenue,
            "profit": profit,
            "roi": roi
        }
    }
